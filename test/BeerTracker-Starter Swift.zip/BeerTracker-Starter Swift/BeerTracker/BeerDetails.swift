//
//  BeerDetails.swift
//  BeerTracker
//
//  Created by ivs on 10/26/15.
//  Copyright © 2015 Anros Applications, LLC. All rights reserved.
//

import UIKit

@objc (BeerDetails)
class BeerDetails: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var image: String
    @NSManaged var note: String
    @NSManaged var rating: Int16
    @NSManaged var beer: Beer
}
