//
//  BeerTracker-BridgingHeader.h
//  BeerTracker
//
//  Copyright (c) 2015 Ray Wenderlich. All rights reserved.
//

#ifndef BeerTracker_BeerTracker_BridgingHeader_h
#define BeerTracker_BeerTracker_BridgingHeader_h

#define MR_SHORTHAND

// &lt; = <  and  $gt; = >
//#import &lt;CoreData+MagicalRecord.h&gt;
#import <CoreData+MagicalRecord.h>
#import <AMRatingControl.h>

#endif
