//
//  Beer.swift
//  BeerTracker
//
//  Created by ivs on 10/26/15.
//  Copyright © 2015 Anros Applications, LLC. All rights reserved.
//

import UIKit
@objc(Beer)
class Beer: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var beerDetails: NSSet
}
