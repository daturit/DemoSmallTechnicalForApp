//
//  main.m
//  ATBasicSounds
//
//  Created by Audrey M Tam on 20/03/2014.
//  Copyright (c) 2014 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ATBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ATBAppDelegate class]));
    }
}
